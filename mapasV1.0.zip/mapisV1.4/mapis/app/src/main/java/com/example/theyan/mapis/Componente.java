package com.example.theyan.mapis;

public interface Componente {

    public String mostrarDatos();

}

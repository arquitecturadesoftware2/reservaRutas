package com.example.theyan.mapis;

public class Reserva {
    private String pasajero;
    private String ruta;
    private String hora;


    public Reserva(String pasajero, String ruta, String hora) {
        this.pasajero = pasajero;
        this.ruta = ruta;
        this.hora = hora;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }



    public String getPasajero() {
        return pasajero;
    }

    public void setPasajero(String pasajero) {
        this.pasajero = pasajero;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }


}

